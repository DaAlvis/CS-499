package com.example.task;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    void setUp() {
        taskService = new TaskService();
    }

    @Test
    void addTaskSuccessfully() {
        Task task = new Task("1", "Task", "Desc");
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("1"));
    }

    @Test
    void addDuplicateTaskThrowsException() {
        Task task = new Task("1", "Task", "Desc");
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task));
    }

    @Test
    void deleteTaskSuccessfully() {
        Task task = new Task("1", "Task", "Desc");
        taskService.addTask(task);
        taskService.deleteTask("1");
        assertNull(taskService.getTask("1"));
    }

    @Test
    void deleteNonexistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("nope"));
    }

    @Test
    void updateTaskNameAndDescriptionSuccessfully() {
        Task task = new Task("1", "Old", "Old Desc");
        taskService.addTask(task);
        taskService.updateTaskName("1", "New");
        taskService.updateTaskDescription("1", "New Desc");
        Task updatedTask = taskService.getTask("1");
        assertEquals("New", updatedTask.getName());
        assertEquals("New Desc", updatedTask.getDescription());
    }

    @Test
    void updateNonexistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("nope", "Name"));
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskDescription("nope", "Desc"));
    }
}
