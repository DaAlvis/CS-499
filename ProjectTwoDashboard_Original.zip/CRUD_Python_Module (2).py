from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username='aacuser', password='YourSecurePassword123'):        
        # Connection Variables
        USER = 'aacuser'
        PASS = 'YourSecurePassword123'  # replace with your actual password
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'
        
        # Use passed-in credentials
        USER = username
        PASS = password

        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create method to implement the C in CRUD
    def create(self, data):
        """Insert a single document into the animals collection"""
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"Error inserting document: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Read method to implement the R in CRUD
    def read(self, query=None):
        """Query documents from the animals collection and return a list"""
        try:
            if query:
                return list(self.collection.find(query))
            else:
                return list(self.collection.find())
        except Exception as e:
            print(f"Error querying documents: {e}")
            return []
    # Update method to implement the U in CRUD
    def update(self, query, update_data):
        """Update document(s) in the animals collection based on query"""
        if query is not None and update_data is not None:
            try:
                result = self.collection.update_many(query, update_data)
                return result.modified_count
            except Exception as e:
                print(f"Error updating document(s): {e}")
                return 0
        else:
            raise Exception("Query and update_data parameters must not be empty")

    # Delete method to implement the D in CRUD
    def delete(self, query):
        """Delete document(s) from the animals collection based on query"""
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"Error deleting document(s): {e}")
                return 0
        else:
            raise Exception("Query parameter must not be empty")
