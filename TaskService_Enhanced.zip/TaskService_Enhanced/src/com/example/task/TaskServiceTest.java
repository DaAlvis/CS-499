package com.example.task;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    void setUp() {
        taskService = new TaskService();
    }

    @Test
    void addTaskSuccessfully() {
        Task task = new Task("1", "Task", "Desc", 3, LocalDate.of(2026, 2, 1));
        taskService.addTask(task);
        assertEquals(task, taskService.getTask("1"));
    }

    @Test
    void addDuplicateTaskThrowsException() {
        Task task = new Task("1", "Task", "Desc", 2, LocalDate.of(2026, 2, 1));
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task));
    }

    @Test
    void deleteTaskSuccessfully() {
        Task task = new Task("1", "Task", "Desc", 1, LocalDate.of(2026, 2, 1));
        taskService.addTask(task);
        taskService.deleteTask("1");
        assertNull(taskService.getTask("1"));
    }

    @Test
    void deleteNonexistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("nope"));
    }

    @Test
    void updateTaskPropertiesSuccessfully() {
        Task task = new Task("1", "Old", "Old Desc", 2, LocalDate.of(2026, 2, 1));
        taskService.addTask(task);
        taskService.updateTaskName("1", "New");
        taskService.updateTaskDescription("1", "New Desc");
        taskService.updateTaskPriority("1", 4);
        taskService.updateTaskDueDate("1", LocalDate.of(2026, 3, 1));

        Task updatedTask = taskService.getTask("1");
        assertEquals("New", updatedTask.getName());
        assertEquals("New Desc", updatedTask.getDescription());
        assertEquals(4, updatedTask.getPriority());
        assertEquals(LocalDate.of(2026, 3, 1), updatedTask.getDueDate());
    }

    @Test
    void updateNonexistentTaskThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("nope", "Name"));
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskDescription("nope", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskPriority("nope", 1));
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskDueDate("nope", LocalDate.now()));
    }

    @Test
    void filterTasksByPriority() {
        Task t1 = new Task("1", "Task1", "Desc1", 1, LocalDate.of(2026, 2, 1));
        Task t2 = new Task("2", "Task2", "Desc2", 2, LocalDate.of(2026, 2, 2));
        Task t3 = new Task("3", "Task3", "Desc3", 1, LocalDate.of(2026, 2, 3));
        taskService.addTask(t1);
        taskService.addTask(t2);
        taskService.addTask(t3);

        List<Task> filtered = taskService.filterTasksByPriority(1);
        assertEquals(2, filtered.size());
        assertTrue(filtered.contains(t1));
        assertTrue(filtered.contains(t3));
    }

    @Test
    void sortTasksByDueDate() {
        Task t1 = new Task("1", "Task1", "Desc1", 1, LocalDate.of(2026, 3, 1));
        Task t2 = new Task("2", "Task2", "Desc2", 2, LocalDate.of(2026, 2, 1));
        Task t3 = new Task("3", "Task3", "Desc3", 3, LocalDate.of(2026, 1, 1));
        taskService.addTask(t1);
        taskService.addTask(t2);
        taskService.addTask(t3);

        List<Task> sorted = taskService.getTasksSortedByDueDate();
        assertEquals(List.of(t3, t2, t1), sorted);
    }
}
