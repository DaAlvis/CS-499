from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(
        self,
        username,
        password,
        host="localhost",
        port=27017,
        db_name="aac",
        collection_name="animals"
    ):
        self.client = MongoClient(
            f"mongodb://{username}:{password}@{host}:{port}/?authSource=admin"
        )
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    # CREATE
    def create(self, data):
        """Insert a single document into the animals collection"""
        if not data:
            raise ValueError("Data parameter cannot be empty")

        try:
            self.collection.insert_one(data)
            return True
        except Exception as e:
            print(f"Error inserting document: {e}")
            return False

    # READ
    def read(self, query=None, projection=None):
        """
        Query documents from the animals collection.
        Supports projections to limit returned fields.
        """
        try:
            if query is None:
                query = {}

            # Default projection hides MongoDB internal ID
            if projection is None:
                projection = {"_id": 0}

            return list(self.collection.find(query, projection))
        except Exception as e:
            print(f"Error querying documents: {e}")
            return []

    # UPDATE
    def update(self, query, update_data):
        """
        Update a specific document using $set only.
        Prevents accidental mass updates.
        """
        if not query or not update_data:
            raise ValueError("Query and update_data parameters must not be empty")

        # Enforce targeted updates
        if "_id" not in query:
            raise ValueError("Updates must target a specific document by _id")

        # Enforce safe update operator
        if "$set" not in update_data:
            raise ValueError("Only $set updates are permitted")

        try:
            result = self.collection.update_one(query, update_data)
            return result.modified_count
        except Exception as e:
            print(f"Error updating document: {e}")
            return 0

    # DELETE
    def delete(self, query):
        """
        Delete a single document by _id only.
        Prevents accidental mass deletion.
        """
        if not query or "_id" not in query:
            raise ValueError("Deletes must target a specific document by _id")

        try:
            result = self.collection.delete_one(query)
            return result.deleted_count
        except Exception as e:
            print(f"Error deleting document: {e}")
            return 0