package com.example.task;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    void validTaskIsCreated() {
        Task task = new Task("12345", "Test Task", "Test Description");
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("Test Description", task.getDescription());
    }

    @Test
    void invalidTaskIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Desc"));
    }

    @Test
    void invalidNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task("123", null, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "N".repeat(21), "Desc"));
    }

    @Test
    void invalidDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "Name", "D".repeat(51)));
    }

    @Test
    void updateNameAndDescriptionWorks() {
        Task task = new Task("123", "Old", "Old Desc");
        task.setName("New");
        task.setDescription("New Desc");
        assertEquals("New", task.getName());
        assertEquals("New Desc", task.getDescription());
    }
}
