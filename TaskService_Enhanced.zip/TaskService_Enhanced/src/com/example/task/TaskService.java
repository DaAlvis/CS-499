package com.example.task;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null || tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task already exists or is null");
        }
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }
        tasks.remove(taskId);
    }

    public void updateTaskName(String taskId, String newName) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        task.setName(newName);
    }

    public void updateTaskDescription(String taskId, String newDescription) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        task.setDescription(newDescription);
    }

    public void updateTaskPriority(String taskId, int newPriority) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        task.setPriority(newPriority);
    }

    public void updateTaskDueDate(String taskId, LocalDate newDate) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found");
        }
        task.setDueDate(newDate);
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    // =========================
    // New: Filter and sort methods
    // =========================

    // Return all tasks sorted by priority (ascending, 1 = highest)
    public List<Task> getTasksSortedByPriority() {
        return tasks.values().stream()
                .sorted(Comparator.comparingInt(Task::getPriority))
                .collect(Collectors.toList());
    }

    // Return all tasks sorted by due date (earliest first)
    public List<Task> getTasksSortedByDueDate() {
        return tasks.values().stream()
                .sorted(Comparator.comparing(Task::getDueDate))
                .collect(Collectors.toList());
    }

    // Filter tasks by priority
    public List<Task> filterTasksByPriority(int priority) {
        return tasks.values().stream()
                .filter(t -> t.getPriority() == priority)
                .collect(Collectors.toList());
    }

    // Filter tasks by due date range
    public List<Task> filterTasksByDueDate(LocalDate start, LocalDate end) {
        return tasks.values().stream()
                .filter(t -> !t.getDueDate().isBefore(start) && !t.getDueDate().isAfter(end))
                .collect(Collectors.toList());
    }

    // Filter tasks by name keyword
    public List<Task> searchTasksByName(String keyword) {
        return tasks.values().stream()
                .filter(t -> t.getName().toLowerCase().contains(keyword.toLowerCase()))
                .collect(Collectors.toList());
    }
}
