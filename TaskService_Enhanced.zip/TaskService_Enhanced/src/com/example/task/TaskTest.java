package com.example.task;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    void validTaskIsCreated() {
        Task task = new Task("12345", "Test Task", "Test Description", 1, LocalDate.of(2026, 2, 1));
        assertEquals("12345", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("Test Description", task.getDescription());
        assertEquals(1, task.getPriority());
        assertEquals(LocalDate.of(2026, 2, 1), task.getDueDate());
    }

    @Test
    void invalidTaskIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc", 1, LocalDate.now()));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Desc", 1, LocalDate.now()));
    }

    @Test
    void invalidNameThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task("123", null, "Desc", 1, LocalDate.now()));
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "N".repeat(21), "Desc", 1, LocalDate.now()));
    }

    @Test
    void invalidDescriptionThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "Name", null, 1, LocalDate.now()));
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "Name", "D".repeat(51), 1, LocalDate.now()));
    }

    @Test
    void updateNameDescriptionPriorityDueDateWorks() {
        Task task = new Task("123", "Old", "Old Desc", 2, LocalDate.of(2026, 2, 1));
        task.setName("New");
        task.setDescription("New Desc");
        task.setPriority(1);
        task.setDueDate(LocalDate.of(2026, 3, 1));

        assertEquals("New", task.getName());
        assertEquals("New Desc", task.getDescription());
        assertEquals(1, task.getPriority());
        assertEquals(LocalDate.of(2026, 3, 1), task.getDueDate());
    }

    @Test
    void invalidPriorityThrowsException() {
        Task task = new Task("123", "Name", "Desc", 1, LocalDate.now());
        assertThrows(IllegalArgumentException.class, () -> task.setPriority(0));
        assertThrows(IllegalArgumentException.class, () -> task.setPriority(6)); // assuming 1-5 is valid
    }

    @Test
    void nullDueDateThrowsException() {
        Task task = new Task("123", "Name", "Desc", 1, LocalDate.now());
        assertThrows(IllegalArgumentException.class, () -> task.setDueDate(null));
    }
}
